#include <stdio.h>

void flow_ctrl_init();

/* DUT as sender */
/* should be invoked on a get request */
void notify_chunk_trans_start(int peer_num, int chunk_num);
int update_sender_window(int peer_num, int ack_num);
void notify_packet_sent(int peer_num, int seq_num, int chunk_num);
void notify_ack_recvied(int peer_num, int ack_num, int chunk_num);

/* DUT as receiver */
/* should be invoked on sending a get request */
void notify_chunk_dwnl_start(int peer_num, int chunk_num);
int update_receiver_window(int peer_num, int seq_num);
/* should be invoked when correct packet of a chunk received */
int notify_packet_recv(int peer_num, int seq_num, int chunk_num);
void notify_ack_sent(int peer_num, int ack_num, int chunk_num);

/* applications internal function */
void recv_chunk(int peer_num, int seq_num, int chunk_num);
void recv_ack(int peer_num, int seq_num, int chunk_num);

/* Invoked by flow control: application needs to implement these */
void send_chunk(int peer_num, int seq_num, int chunk_num);
void send_ack(int peer_num, int seq_num, int chunk_num);

/* test functions */
int test_dut_sender();
int test_dut_receiver();


int main()
{
	flow_ctrl_init();

	test_dut_sender();
	//test_dut_receiver();

	return 0;
}

int test_dut_receiver()
{

	int peer_num 	= 8;
	int chunk_num 	= 27;

	/* test DUT as receiver */

	/* Sent a get request to some other peer, numbered peer_num */
	notify_chunk_dwnl_start(peer_num, chunk_num);

	/* TODO: Need some other kind of timeout to detect unresponsive peer */

	int i = 1;
	notify_packet_recv(peer_num, i, chunk_num);

	/* Ack out: 1 to 1 */

	for(i=2; i<= 11; i++)
		notify_packet_recv(peer_num, i, chunk_num);

	/*Ack out: 2 to 11*/

	/* Now try packet loss : packet 13 is lost */
	i = 12;
	notify_packet_recv(peer_num, i, chunk_num);

	i = 14;
	notify_packet_recv(peer_num, i, chunk_num);

	i = 15;
	notify_packet_recv(peer_num, i, chunk_num);

	i = 16;
	notify_packet_recv(peer_num, i, chunk_num);

	/* Ack out: 12  12  12 12 */

	/* now test cumulative ack */
	/* packet 13 is received */

	i = 13;
	notify_packet_recv(peer_num, i, chunk_num);

	/* Ack out: 16 */

	/* Now test discarding the packet outside the range and packet drop */
	/* packet 17 to 40 is received, expect packet 18 */
	for(i=17; i<=40; i++)
	{
		if(i != 18)
			notify_packet_recv(peer_num, i, chunk_num);
	}

	/* Ack out: 17 17 17 .... 17 */

	/* Now test dropping the packets outside window */
	/* Now assume lost packet 18 is received */
	i = 18;
	notify_packet_recv(peer_num, i, chunk_num);

	/* Ack out: 25 , NOT 40 */

	return 0;
}


int test_dut_sender()
{

	int peer_num = 7;
	int chunk_num = 23;

	int i=1;

	/* test DUT as sender */

	/* Received a get request from some other peer, numbered peer_num */
	notify_chunk_trans_start(peer_num, chunk_num);

	/* Packet sent out: 1 to 8 */

	/* Acks received: 1 to 4 */
	for(i=1; i<=4; i++)
		notify_ack_recvied(peer_num, i, chunk_num);

	/* Packets sent out: 9 to 12 */

	/* Acks received: 5 to 12 */
	for(i=5; i<=12; i++)
		notify_ack_recvied(peer_num, i, chunk_num);

	/* packets sent: 13 to 20 */

	/* Now simulate cumulative acks */
	/* simply ack 19 */
	i = 19;
	notify_ack_recvied(peer_num, i, chunk_num);

	/* packets sent: 21 to 27 */

	/* again check cumulative acks */
	i = 27;
	notify_ack_recvied(peer_num, i, chunk_num);

	/* packets sent: 28 to 35 */

	/* one more time cumulative ack */
	i = 29;
	notify_ack_recvied(peer_num, i, chunk_num);

	/* packets sent: 36 to 37 */

	/* Now simulate packet loss indicated by duplicate acks */
	/* currently unacked packets are: 30 to 37 */
	/* assume 30th packet is lost */
	i = 29;
	notify_ack_recvied(peer_num, i, chunk_num);

	/* No packet should come out this time as till now only 2 acks */

	i = 29;
	notify_ack_recvied(peer_num, i, chunk_num);

	/* Now packet no. 30 should come out, not 38 */

	/* here timeout test can go */

	/* cumulative ack */
	i = 37;
	notify_ack_recvied(peer_num, i, chunk_num);

	/* Packets sent out: 38 to 45 */

	/* Again time for packet loss: duplicate acks */
	/* Assume 43rd packet is lost */
	i = 42;
	notify_ack_recvied(peer_num, i, chunk_num);
	
	/* first packet: 46 to 50 should come out */

	i = 42;
	notify_ack_recvied(peer_num, i, chunk_num);

	/* No packet should come out */

	i = 42;
	notify_ack_recvied(peer_num, i, chunk_num);

	/* now packet no. 43 should come out, not 51 */

	i = 50;
	notify_ack_recvied(peer_num, i, chunk_num);

	/* packets out: 51 to 58 */

	/* check end of chunk condition */
	i = 58;
	notify_ack_recvied(peer_num, i, chunk_num);

	/* packets out: 59 to 60 */
	/* and then couple of transmission done msg */

	return 0;
}


/* applications internal function */
void recv_chunk(int peer_num, int seq_num, int chunk_num)
{
	printf("recv_chunk - peer_num:%d  seq_num:%d   chunk_num:%d\n", peer_num, seq_num, chunk_num);
}

void recv_ack(int peer_num, int seq_num, int chunk_num)
{
	printf("recv_ack - peer_num:%d  seq_num:%d   chunk_num:%d\n", peer_num, seq_num, chunk_num);
}

/* Invoked by flow control: application needs to implement these */
void send_chunk(int peer_num, int seq_num, int chunk_num)
{
	if(seq_num > 60)		// max_num of packets possible for a chunk: access using some global
	{
		printf("send_chunk: Transmission done\n");
		return;
	}
	printf("send_chunk - peer_num:%d  seq_num:%d   chunk_num:%d\n", peer_num, seq_num, chunk_num);
	notify_packet_sent(peer_num, seq_num, chunk_num);
}

void send_ack(int peer_num, int seq_num, int chunk_num)
{
	printf("send_ack - peer_num:%d  seq_num:%d   chunk_num:%d\n", peer_num, seq_num, chunk_num);
}